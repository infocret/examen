Examen tecnico C&A 
Julio Buendía

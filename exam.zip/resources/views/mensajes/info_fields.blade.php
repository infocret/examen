
<div class="form-group">
    {!! Form::label('dowcod', 'Descargar codigo:') !!}
    
</div>

<div class="form-group">
    {!! Form::label('dowscript', 'Descargar script:') !!}
    
</div>

<div class="form-group">
    {!! Form::label('dbrem', 'Acceso remoto a DB:') !!}
    
</div>

<div class="form-group">
    {!! Form::label('gith', 'Repositorio Git:') !!}
    
</div>

<div class="form-group">
    {!! Form::label('ytube', 'Video youtube:') !!}
    
</div>


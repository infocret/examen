<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $mensaje->id !!}</p>
</div>

<!-- Mensaje Field -->
<div class="form-group">
    {!! Form::label('mensaje', 'Mensaje:') !!}
    <p>{!! $mensaje->mensaje !!}</p>
</div>


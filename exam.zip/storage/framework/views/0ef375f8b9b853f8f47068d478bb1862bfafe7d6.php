<table class="table table-responsive" id="mensajes-table">
    <thead>
        <tr>
            <th>Mensaje</th>
            <th colspan="3">Acción</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $mensajes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mensaje): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo $mensaje->mensaje; ?></td>
            <td>
                <?php echo Form::open(['route' => ['mensajes.destroy', $mensaje->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('mensajes.show', [$mensaje->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('mensajes.edit', [$mensaje->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Seguro?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
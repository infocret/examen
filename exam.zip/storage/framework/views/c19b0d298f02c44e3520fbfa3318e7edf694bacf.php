

<?php if(Auth::user()->rol_id == 1): ?>

<li class="<?php echo e(Request::is('users*') ? 'active' : ''); ?>">
    <a href="<?php echo route('users.index'); ?>"><i class="fa fa-edit"></i><span>Usuarios</span></a>
</li>

<?php endif; ?>

<li class="<?php echo e(Request::is('roles*') ? 'active' : ''); ?>">
    <a href="<?php echo route('roles.index'); ?>"><i class="fa fa-edit"></i><span>Roles</span></a>
</li>

<li class="<?php echo e(Request::is('mensajes*') ? 'active' : ''); ?>">
    <a href="<?php echo route('mensajes.index'); ?>"><i class="fa fa-edit"></i><span>Mensajes</span></a>
</li>


       <li class="<?php echo e(Request::is('mensaje.info*') ? 'active' : ''); ?>">
          <a href="<?php echo route('mensaje.info'); ?>">
          <i class="fa fa-edit"></i><span>Información</span>
          </a>
      </li>

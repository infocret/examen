<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $user->id; ?></p>
</div>

<!-- Name Field -->
<div class="form-group">
    <?php echo Form::label('name', 'Nombre:'); ?>

    <p><?php echo $user->name; ?></p>
</div>

<!-- Email Field -->
<div class="form-group">
    <?php echo Form::label('email', 'e-mail:'); ?>

    <p><?php echo $user->email; ?></p>
</div>

<!-- Rol Field -->
<div class="form-group">
    <?php echo Form::label('rol', 'Rol:'); ?>

    <p><?php echo $user->rol_id; ?></p>
</div>


<!-- Password Field -->
<div class="form-group">
    <?php echo Form::label('password', 'Contraseña:'); ?>

    <p><?php echo $user->password; ?></p>
</div>

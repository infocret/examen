<!-- Rol Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('rol', 'Rol:'); ?>

    <?php echo Form::text('rol', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('roles.index'); ?>" class="btn btn-default">Cancelar</a>
</div>

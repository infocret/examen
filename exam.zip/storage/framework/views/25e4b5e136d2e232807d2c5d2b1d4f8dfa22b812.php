<table class="table table-responsive" id="propaccounts-table">
    <thead>
        <tr>
            <th>Inmueble Id</th>
        <th>Bankaccount Id</th>
        <th>Checkbook Id</th>
        <th>Bank Agreement</th>
            <th colspan="3">Action</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $propaccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $propaccount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo $propaccount->inmueble_id; ?></td>
            <td><?php echo $propaccount->bankaccount_id; ?></td>
            <td><?php echo $propaccount->checkbook_id; ?></td>
            <td><?php echo $propaccount->bank_agreement; ?></td>
            <td>
                <?php echo Form::open(['route' => ['propaccounts.destroy', $propaccount->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('propaccounts.show', [$propaccount->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('propaccounts.edit', [$propaccount->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
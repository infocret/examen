<!-- Inmueble Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('inmueble_id', 'Inmueble Id:'); ?>

    <?php echo Form::number('inmueble_id', null, ['class' => 'form-control']); ?>

</div>

<!-- Bankaccount Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('bankaccount_id', 'Bankaccount Id:'); ?>

    <?php echo Form::number('bankaccount_id', null, ['class' => 'form-control']); ?>

</div>

<!-- Checkbook Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('checkbook_id', 'Checkbook Id:'); ?>

    <?php echo Form::number('checkbook_id', null, ['class' => 'form-control']); ?>

</div>

<!-- Bank Agreement Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('bank_agreement', 'Bank Agreement:'); ?>

    <?php echo Form::text('bank_agreement', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('propaccounts.index'); ?>" class="btn btn-default">Cancel</a>
</div>

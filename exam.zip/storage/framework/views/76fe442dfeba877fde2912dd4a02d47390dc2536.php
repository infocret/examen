<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $role->id; ?></p>
</div>

<!-- Rol Field -->
<div class="form-group">
    <?php echo Form::label('rol', 'Rol:'); ?>

    <p><?php echo $role->rol; ?></p>
</div>

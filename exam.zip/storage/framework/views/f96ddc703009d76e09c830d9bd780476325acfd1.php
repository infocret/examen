
<div class="form-group col-sm-6">
    <?php echo Form::label('name', 'Nombre:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

</div>


<div class="form-group col-sm-6">
    <?php echo Form::label('email', 'e-mail:'); ?>

    <?php echo Form::text('email', null, ['class' => 'form-control']); ?>

</div>

<div class="form-group col-sm-4">
    <?php echo Form::label('lrol', 'Rol:'); ?>

    <select name="rol_id" id="rol_id" class="form-control"  required>
    <option value="">Seleccione Rol</option>   
    <?php if(isset($user)&& !empty($user)): ?>  
	    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>            
	        <option value="<?php echo e($rol->id); ?>"
	         	<?php echo e($user->rol_id == $rol->id ? 'selected="selected"' : ''); ?> 
	        ><?php echo e($rol->rol); ?>

	        </option>            
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?> 
        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>            
        <option value="<?php echo e($rol->id); ?>"         
        ><?php echo e($rol->rol); ?>

        </option>            
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    </select>



</div>

<div class="form-group col-sm-6">
    <?php echo Form::label('password', 'Contraseña:'); ?>

    <?php echo Form::password('password', null, ['class' => 'form-control']); ?>

</div>


<div class="form-group col-sm-6">        
    <input type="hidden" name="remember_token" value="n/a">
</div>


<div class="form-group col-sm-12">
    <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('users.index'); ?>" class="btn btn-default">Cancelar</a>
</div>

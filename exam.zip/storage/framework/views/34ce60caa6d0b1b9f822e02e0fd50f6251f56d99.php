
<div class="form-group">
    <?php echo Form::label('dowcod', 'Descargar codigo:'); ?>

    
</div>

<div class="form-group">
    <?php echo Form::label('dowscript', 'Descargar script:'); ?>

    
</div>

<div class="form-group">
    <?php echo Form::label('dbrem', 'Acceso remoto a DB:'); ?>

    
</div>

<div class="form-group">
    <?php echo Form::label('gith', 'Repositorio Git:'); ?>

    
</div>

<div class="form-group">
    <?php echo Form::label('ytube', 'Video youtube:'); ?>

    
</div>

